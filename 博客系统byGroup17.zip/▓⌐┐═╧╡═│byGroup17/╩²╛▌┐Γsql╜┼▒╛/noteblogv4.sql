/*
SQLyog Ultimate v12.08 (64 bit)
MySQL - 5.7.30-log : Database - noteblogv4
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
CREATE DATABASE /*!32312 IF NOT EXISTS*/`noteblogv4` /*!40100 DEFAULT CHARACTER SET utf8 */;

USE `noteblogv4`;

/*Table structure for table `nb_about` */

DROP TABLE IF EXISTS `nb_about`;

CREATE TABLE `nb_about` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `content` text NOT NULL,
  `md_content` text NOT NULL,
  `name` varchar(50) DEFAULT NULL,
  `tab` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `nb_about` */

/*Table structure for table `nb_article` */

DROP TABLE IF EXISTS `nb_article`;

CREATE TABLE `nb_article` (
  `id` bigint(20) NOT NULL,
  `appreciable` tinyint(1) NOT NULL DEFAULT '0',
  `approve_cnt` int(11) NOT NULL,
  `author_id` bigint(20) DEFAULT NULL,
  `cate_id` bigint(20) NOT NULL,
  `commented` tinyint(1) NOT NULL DEFAULT '0',
  `content` text NOT NULL,
  `cover` varchar(255) DEFAULT NULL,
  `draft` tinyint(1) NOT NULL DEFAULT '1',
  `md_content` text,
  `modify` datetime DEFAULT NULL,
  `post` datetime NOT NULL,
  `summary` varchar(300) DEFAULT NULL,
  `text_content` text,
  `title` varchar(100) NOT NULL,
  `top` int(11) DEFAULT NULL,
  `url_seq` varchar(100) DEFAULT NULL,
  `view` int(11) NOT NULL,
  `cate_refer_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FKm9lpoad6mhygm6ybseq2kkg30` (`cate_refer_id`),
  CONSTRAINT `FKm9lpoad6mhygm6ybseq2kkg30` FOREIGN KEY (`cate_refer_id`) REFERENCES `nb_cate` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `nb_article` */

insert  into `nb_article`(`id`,`appreciable`,`approve_cnt`,`author_id`,`cate_id`,`commented`,`content`,`cover`,`draft`,`md_content`,`modify`,`post`,`summary`,`text_content`,`title`,`top`,`url_seq`,`view`,`cate_refer_id`) values (1590930750053,0,150,1,1,1,'<h3 id=\"h3-fight-\"><a name=\"Fightだよ！\" class=\"reference-link\"></a><span class=\"header-link octicon octicon-link\"></span>Fightだよ！</h3><p>高坂穗乃果是音乃木阪学院校园偶像团体μ’s的发起人兼leader。现为音乃木坂学院二年级生。因为得知了音乃木阪学院即将废校的事实而决定成立偶像组合以增加学院的人气增加生源，达到阻止废校的目的。在TV动画第一季中，因为自己生病，μ’s退出LoveLive!的比赛。在第二季中与其他八人再次参加LoveLive!并荣获冠军。<br><img src=\"/upfiles/img/2020-05-31/d7c6fe8f-a660-4ac8-bac5-deac6a548e46.jpg\" alt=\"\"></p>\n','/upfiles/img/2020-05-31/7701a8f7-50a4-42eb-983e-ad023fb85e36.jpg',0,'### Fightだよ！\n高坂穗乃果是音乃木阪学院校园偶像团体μ\'s的发起人兼leader。现为音乃木坂学院二年级生。因为得知了音乃木阪学院即将废校的事实而决定成立偶像组合以增加学院的人气增加生源，达到阻止废校的目的。在TV动画第一季中，因为自己生病，μ’s退出LoveLive!的比赛。在第二季中与其他八人再次参加LoveLive!并荣获冠军。\n![](/upfiles/img/2020-05-31/d7c6fe8f-a660-4ac8-bac5-deac6a548e46.jpg)',NULL,'2020-05-31 21:12:30','Fightだよ！高坂穗乃果是音乃木阪学院校园偶像团体μ’s的发起人兼leader。现为音乃木坂学院二年级生。因为得知了音乃木阪学院即将废校的事实而决定成立偶像组合以增加学院的人气增加生源，达到阻止废校的','Fightだよ！高坂穗乃果是音乃木阪学院校园偶像团体μ’s的发起人兼leader。现为音乃木坂学院二年级生。因为得知了音乃木阪学院即将废校的事实而决定成立偶像组合以增加学院的人气增加生源，达到阻止废校的目的。在TV动画第一季中，因为自己生病，μ’s退出LoveLive!的比赛。在第二季中与其他八人再次参加LoveLive!并荣获冠军。','高坂穗乃果 介绍',0,'',855,1),(1590933559607,0,157,1,1,1,'<p>由于web得天独厚的轻量化以及平台无关性，当今web应用的场景越来越广。而市面上大量的web应用。包括网页网站，手机APP等等，有一些备受人们青睐，有些却使用体验不佳。下面我就来分析对比一些我喜欢的web网站，以及一些我觉得使用体验不佳的应用。通过对比分析来看出，怎样的网站会受使用者喜爱。</p>\n<h2 id=\"h2-1-1-douban\"><a name=\"1.1国内著名社区网站豆瓣   Douban\" class=\"reference-link\"></a><span class=\"header-link octicon octicon-link\"></span>1.1国内著名社区网站豆瓣 <a href=\"http://www.douban.com\" title=\"Douban\">Douban</a></h2><p>作为国内最有名的社区网络之一，豆瓣提供了书影音推荐、线下同城活动、小组话题交流等多种服务功能，它更像一个集品味系统（读书、电影、音乐）、表达系统（我读、我看、我听）和交流系统（同城、小组、友邻）于一体的创新网络服务，一直致力于帮助都市人群发现生活中有用的事物。</p>\n<p><img src=\"/upfiles/img/2020-05-31/a1225858-0ebe-4657-95dc-eb5690bfc6b9.png\" alt=\"\"></p>\n<p>作为社区网站，以用户提供网站最主要的内容，豆瓣有着人性化的交互功能。<br>显眼的登陆入口。书，电影，音乐等各个板块分类放置。并且热点推送算法相当完善。保证热点内容第一时间更新，并出现在主页上。</p>\n<p><img src=\"/upfiles/img/2020-05-31/625e0d1e-c9bd-46c7-85b2-1eb571d5fb6a.png\" alt=\"\"></p>\n<p>作为社区网站，个人页面（相当于blog）是必不可少的内容。豆瓣将个人页面分类排版，<br>各个板块以时间线方式显示。当进入某位用户的主页，可以直接看到他最近的文章，书评，影评。右边栏显示他加入的小组。整体一目了然。</p>\n<p>我认为，豆瓣的设计优秀，在于它做“减法”。无论是网站主页还是个人主页，只放置最核心的内容。而将其他功能收在二级页面。适当的留白使得整个网站观感大幅提升，并且对于新用户，大大减少了使用成本。</p>\n<h3 id=\"h3-u603Bu7ED3\"><a name=\"总结\" class=\"reference-link\"></a><span class=\"header-link octicon octicon-link\"></span>总结</h3><p>  网站设计要从人性化的角度考虑，为用户着想，分析如何设计功能，从而给用户带来便利，而不是麻烦。在初版设计完成后，应多次测试，并倾听用户反馈，不断改善，从而做出好用，实用的网站。  </p>\n','/upfiles/img/2020-05-31/433e9f7a-3352-4360-86a4-320c77f5a425.jpg',0,'由于web得天独厚的轻量化以及平台无关性，当今web应用的场景越来越广。而市面上大量的web应用。包括网页网站，手机APP等等，有一些备受人们青睐，有些却使用体验不佳。下面我就来分析对比一些我喜欢的web网站，以及一些我觉得使用体验不佳的应用。通过对比分析来看出，怎样的网站会受使用者喜爱。\n## 1.1国内著名社区网站豆瓣 [Douban](http://www.douban.com \"Douban\")\n\n作为国内最有名的社区网络之一，豆瓣提供了书影音推荐、线下同城活动、小组话题交流等多种服务功能，它更像一个集品味系统（读书、电影、音乐）、表达系统（我读、我看、我听）和交流系统（同城、小组、友邻）于一体的创新网络服务，一直致力于帮助都市人群发现生活中有用的事物。\n\n![](/upfiles/img/2020-05-31/a1225858-0ebe-4657-95dc-eb5690bfc6b9.png)\n\n\n作为社区网站，以用户提供网站最主要的内容，豆瓣有着人性化的交互功能。\n显眼的登陆入口。书，电影，音乐等各个板块分类放置。并且热点推送算法相当完善。保证热点内容第一时间更新，并出现在主页上。\n\n![](/upfiles/img/2020-05-31/625e0d1e-c9bd-46c7-85b2-1eb571d5fb6a.png)\n\n作为社区网站，个人页面（相当于blog）是必不可少的内容。豆瓣将个人页面分类排版，\n各个板块以时间线方式显示。当进入某位用户的主页，可以直接看到他最近的文章，书评，影评。右边栏显示他加入的小组。整体一目了然。\n\n我认为，豆瓣的设计优秀，在于它做“减法”。无论是网站主页还是个人主页，只放置最核心的内容。而将其他功能收在二级页面。适当的留白使得整个网站观感大幅提升，并且对于新用户，大大减少了使用成本。\n\n###总结\n  网站设计要从人性化的角度考虑，为用户着想，分析如何设计功能，从而给用户带来便利，而不是麻烦。在初版设计完成后，应多次测试，并倾听用户反馈，不断改善，从而做出好用，实用的网站。  ',NULL,'2020-05-31 21:59:20','由于web得天独厚的轻量化以及平台无关性，当今web应用的场景越来越广。而市面上大量的web应用。包括网页网站，手机APP等等，有一些备受人们青睐，有些却使用体验不佳。下面我就来分析对比一些我喜欢的web网站，以及一些我觉得使用体验不佳的应用。通过对比分析来看出，怎样','由于web得天独厚的轻量化以及平台无关性，当今web应用的场景越来越广。而市面上大量的web应用。包括网页网站，手机APP等等，有一些备受人们青睐，有些却使用体验不佳。下面我就来分析对比一些我喜欢的web网站，以及一些我觉得使用体验不佳的应用。通过对比分析来看出，怎样的网站会受使用者喜爱。1.1国内著名社区网站豆瓣Douban作为国内最有名的社区网络之一，豆瓣提供了书影音推荐、线下同城活动、小组话题交流等多种服务功能，它更像一个集品味系统（读书、电影、音乐）、表达系统（我读、我看、','关于网站设计优劣的简要分析',0,'',1000,1);

/*Table structure for table `nb_cate` */

DROP TABLE IF EXISTS `nb_cate`;

CREATE TABLE `nb_cate` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `cn_name` varchar(50) DEFAULT NULL,
  `font_icon` varchar(255) DEFAULT NULL,
  `name` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT;

/*Data for the table `nb_cate` */

insert  into `nb_cate`(`id`,`cn_name`,`font_icon`,`name`) values (1,'空','fa fa-sliders','def_cate');

/*Table structure for table `nb_cloud_file` */

DROP TABLE IF EXISTS `nb_cloud_file`;

CREATE TABLE `nb_cloud_file` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `cate_id` bigint(20) NOT NULL,
  `description` varchar(500) DEFAULT NULL,
  `modify` datetime DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `post` datetime DEFAULT NULL,
  `url` varchar(255) DEFAULT NULL,
  `cate_refer_id` bigint(20) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FKn86tmj8yuyvig9o0d51887pcx` (`cate_refer_id`),
  CONSTRAINT `FKn86tmj8yuyvig9o0d51887pcx` FOREIGN KEY (`cate_refer_id`) REFERENCES `nb_cloud_file_cate` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `nb_cloud_file` */

/*Table structure for table `nb_cloud_file_cate` */

DROP TABLE IF EXISTS `nb_cloud_file_cate`;

CREATE TABLE `nb_cloud_file_cate` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `cn_name` varchar(50) DEFAULT NULL,
  `name` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `nb_cloud_file_cate` */

/*Table structure for table `nb_comment` */

DROP TABLE IF EXISTS `nb_comment`;

CREATE TABLE `nb_comment` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `article_id` bigint(20) NOT NULL,
  `clear_comment` text,
  `comment` text,
  `enable` tinyint(1) NOT NULL,
  `ip_addr` varchar(50) DEFAULT NULL,
  `ip_cn_addr` varchar(100) DEFAULT NULL,
  `post` datetime DEFAULT NULL,
  `user_agent` varchar(255) DEFAULT NULL,
  `user_id` bigint(20) NOT NULL,
  `user_refer_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FKa807vyi2gkp698mm6agk7eifu` (`user_refer_id`),
  CONSTRAINT `FKa807vyi2gkp698mm6agk7eifu` FOREIGN KEY (`user_refer_id`) REFERENCES `sys_user` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

/*Data for the table `nb_comment` */

insert  into `nb_comment`(`id`,`article_id`,`clear_comment`,`comment`,`enable`,`ip_addr`,`ip_cn_addr`,`post`,`user_agent`,`user_id`,`user_refer_id`) values (1,1564936050961,'不错，zuidaima.com验证过','<p>不错，zuidaima.com验证过</p>',0,'127.0.0.1','本地/未知','2019-08-05 00:27:50','Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:69.0) Gecko/20100101 Firefox/69.0',1,1),(2,1564936050961,'哦哦哦','<p>哦哦哦</p>',1,'0:0:0:0:0:0:0:1','本地/未知','2020-05-31 20:39:49','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/83.0.4103.61 Safari/537.36',2,2);

/*Table structure for table `nb_file` */

DROP TABLE IF EXISTS `nb_file`;

CREATE TABLE `nb_file` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `post` datetime DEFAULT NULL,
  `url` varchar(500) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `nb_file` */

/*Table structure for table `nb_function_panel` */

DROP TABLE IF EXISTS `nb_function_panel`;

CREATE TABLE `nb_function_panel` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `jump_msg` varchar(255) DEFAULT NULL,
  `logo_href` varchar(255) NOT NULL,
  `logo_icon` varchar(255) NOT NULL,
  `logo_name` varchar(10) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `nb_function_panel` */

/*Table structure for table `nb_keyword` */

DROP TABLE IF EXISTS `nb_keyword`;

CREATE TABLE `nb_keyword` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `enable` tinyint(1) NOT NULL,
  `words` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `nb_keyword` */

/*Table structure for table `nb_message` */

DROP TABLE IF EXISTS `nb_message`;

CREATE TABLE `nb_message` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `clear_comment` varchar(255) DEFAULT NULL,
  `comment` varchar(255) NOT NULL,
  `enable` tinyint(1) DEFAULT NULL,
  `ip_addr` varchar(50) DEFAULT NULL,
  `ip_cn_addr` varchar(50) DEFAULT NULL,
  `post` datetime DEFAULT NULL,
  `user_agent` varchar(255) DEFAULT NULL,
  `user_id` bigint(20) NOT NULL,
  `user_refer_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FKjldkpoxxyluabgc2jfloi47y4` (`user_refer_id`),
  CONSTRAINT `FKjldkpoxxyluabgc2jfloi47y4` FOREIGN KEY (`user_refer_id`) REFERENCES `sys_user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `nb_message` */

/*Table structure for table `nb_note` */

DROP TABLE IF EXISTS `nb_note`;

CREATE TABLE `nb_note` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `clear_content` text,
  `content` text NOT NULL,
  `md_content` text,
  `modify` datetime DEFAULT NULL,
  `post` datetime NOT NULL,
  `show` tinyint(1) NOT NULL,
  `title` varchar(50) NOT NULL,
  `top` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

/*Data for the table `nb_note` */

insert  into `nb_note`(`id`,`clear_content`,`content`,`md_content`,`modify`,`post`,`show`,`title`,`top`) values (1,'今天学习了SpringBoot框架配合Maven的使用,学到了不少有用的东西!\n','<p>今天学习了SpringBoot框架配合Maven的使用,学到了不少有用的东西!</p>\n','今天学习了SpringBoot框架配合Maven的使用,学到了不少有用的东西!',NULL,'2020-05-31 21:39:30',1,'今天的日记',0);

/*Table structure for table `nb_panel` */

DROP TABLE IF EXISTS `nb_panel`;

CREATE TABLE `nb_panel` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `enable` tinyint(1) NOT NULL,
  `order_index` int(11) NOT NULL,
  `panel_dom` varchar(255) DEFAULT NULL,
  `title_name` varchar(5) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

/*Data for the table `nb_panel` */

insert  into `nb_panel`(`id`,`enable`,`order_index`,`panel_dom`,`title_name`) values (1,1,0,'infoPanel','信息面板'),(2,1,1,'searchPanel','搜索库'),(3,1,2,'functionPanel','功能区'),(4,1,3,'catePanel','分类堆'),(5,1,4,'randomPanel','博文栈'),(6,1,5,'tagPanel','标签页'),(7,1,6,'linkPanel','友链区');

/*Table structure for table `nb_param` */

DROP TABLE IF EXISTS `nb_param`;

CREATE TABLE `nb_param` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `level` int(11) DEFAULT '0',
  `name` varchar(50) NOT NULL,
  `order_index` int(11) DEFAULT '0',
  `remark` varchar(255) DEFAULT NULL,
  `value` varchar(600) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=51 DEFAULT CHARSET=utf8;

/*Data for the table `nb_param` */

insert  into `nb_param`(`id`,`level`,`name`,`order_index`,`remark`,`value`) values (1,0,'init_status',0,'标记用户App 的初始化设置页面设置过','1'),(2,10,'all_comment_open',0,'是否全局开放评论','1'),(3,10,'menu_note_show',0,'导航菜单_笔记是否显示，默认显示','1'),(4,10,'menu_project_show',0,'导航菜单_我的作品是否显示，默认不显示','0'),(5,10,'menu_mine_show',0,'导航菜单_关于我是否显示，默认显示','1'),(6,10,'menu_cloud_file_show',0,'导航菜单_云文件是否显示，默认显示','1'),(7,10,'menu_search_show',0,'导航菜单_搜索是否显示，默认显示','1'),(8,10,'menu_link_show',0,'是否显示额外的导航链接（譬如github）','0'),(9,9,'app_id',0,'qq登录API的app_id',''),(10,9,'app_key',0,'qq登录API的app_key',''),(11,10,'qq_login',0,'是否开放qq登录','0'),(12,0,'is_set_master',0,'是否设置了网站管理员','1'),(13,10,'is_open_message',0,'是否开启留言功能','0'),(14,10,'info_panel_order',0,'网站信息和会员中心显示顺序，1表示网站信息显示在首要位置','1'),(15,9,'upload_type',0,'上传方式类型，默认local，本地上传','LOCAL'),(16,9,'is_open_oss_upload',0,'是否开启云服务器上传，默认0不开启','0'),(17,9,'qiniu_accessKey',0,'七牛云AccessKey',''),(18,9,'qiniu_secretKey',0,'七牛云SecretKey',''),(19,9,'qiniu_bucket',0,'七牛云bucket',''),(20,10,'page_modern',0,'首页博文分页模式0：流式，1：按钮加载','0'),(21,10,'index_style',0,'首页样式，简约/普通（simple/normal）','normal'),(22,-1,'blog_index_page_size',0,'博客首页文章页面数据量大小，大于10才有效,否则则根据参数来判断','10'),(23,10,'statistic_analysis',0,'是否开启访问统计，默认不开启','0'),(24,10,'article_summary_words_length',0,'首页展示文章的摘要的文字数量，默认243','243'),(25,10,'website_title',0,'网站标题的文字','小电博客'),(26,10,'footer_words',0,'页脚的文字','此处一般可写一些备案号之类的文字'),(27,10,'index_top_words',0,'首页置顶文字','实现吧 我们的梦想！'),(28,10,'menu_home',0,'导航菜单_首页','主页'),(29,10,'menu_project',0,'导航菜单_我的作品','作品'),(30,10,'menu_note',0,'导航菜单_笔记','笔记'),(31,10,'menu_link',0,'导航菜单_额外的链接','代码'),(32,10,'menu_link_icon',0,'导航菜单_额外的链接的字体图标logo','fa fa-code'),(33,10,'menu_link_href',0,'导航菜单_额外的链接url',''),(34,10,'menu_mine',0,'导航菜单_关于我','关于'),(35,10,'menu_cloud_file',0,'导航菜单_云文件','文件'),(36,11,'wechat_pay',0,'微信付款码','/static/assets/img/wechat.png'),(37,11,'alipay',0,'支付宝付款码','/static/assets/img/alipay.png'),(38,10,'info_label',0,'信息板内容','此处填写网站的一些信息'),(39,10,'menu_search',0,'导航菜单_搜索','搜索'),(40,10,'website_logo_words',0,'网站logo的文字','小电博客'),(41,10,'website_logo_small_words',0,'网站logo的文字旁的小字',''),(42,10,'comment_notice',0,'评论置顶公告','欢迎评论！'),(43,10,'project_top_notice',0,'项目置顶公告','资源分享'),(44,10,'message_panel_words',0,'留言板的提示信息文字','欢迎大家'),(45,10,'qiniu_domain',0,'七牛云文件服务器域名',''),(46,8,'mail_smpt_server_addr',0,'SMTP服务器',''),(47,8,'mail_smpt_server_port',0,'SMTP端口号',''),(48,8,'mail_server_account',0,'发件人邮箱','229670104@qq.com'),(49,8,'mail_sender_name',0,'发件人邮箱帐号（一般为@前面部分）','nbv4_user'),(50,8,'mail_server_password',0,'邮箱登入密码','');

/*Table structure for table `nb_project` */

DROP TABLE IF EXISTS `nb_project`;

CREATE TABLE `nb_project` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `cate_id` bigint(20) NOT NULL,
  `cover` varchar(255) NOT NULL,
  `description` varchar(255) DEFAULT NULL,
  `modify` datetime DEFAULT NULL,
  `name` varchar(11) NOT NULL,
  `post` datetime DEFAULT NULL,
  `url` varchar(255) DEFAULT NULL,
  `cate_refer_id` bigint(20) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FKtiswf2lccadae70gsjrd40x6t` (`cate_refer_id`),
  CONSTRAINT `FKtiswf2lccadae70gsjrd40x6t` FOREIGN KEY (`cate_refer_id`) REFERENCES `nb_project_cate` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `nb_project` */

/*Table structure for table `nb_project_cate` */

DROP TABLE IF EXISTS `nb_project_cate`;

CREATE TABLE `nb_project_cate` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `cn_name` varchar(50) DEFAULT NULL,
  `name` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `nb_project_cate` */

/*Table structure for table `nb_tag` */

DROP TABLE IF EXISTS `nb_tag`;

CREATE TABLE `nb_tag` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UK6tfxkiyl7xpuxll97e045281a` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

/*Data for the table `nb_tag` */

insert  into `nb_tag`(`id`,`name`) values (2,'技术'),(1,'杂谈');

/*Table structure for table `nb_tag_refer` */

DROP TABLE IF EXISTS `nb_tag_refer`;

CREATE TABLE `nb_tag_refer` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `refer_id` bigint(20) NOT NULL,
  `show` tinyint(1) NOT NULL,
  `tag_id` bigint(20) NOT NULL,
  `type` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8;

/*Data for the table `nb_tag_refer` */

insert  into `nb_tag_refer`(`id`,`refer_id`,`show`,`tag_id`,`type`) values (1,1563610016078,1,1,'article'),(2,1563759339226,1,1,'article'),(3,1564936050961,1,2,'article'),(6,1590930750053,1,1,'article'),(7,1,1,2,'note'),(10,1590933559607,1,2,'article');

/*Table structure for table `nb_upload` */

DROP TABLE IF EXISTS `nb_upload`;

CREATE TABLE `nb_upload` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `disk_path` varchar(255) NOT NULL,
  `type` varchar(50) NOT NULL,
  `upload` datetime DEFAULT NULL,
  `virtual_path` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;

/*Data for the table `nb_upload` */

insert  into `nb_upload`(`id`,`disk_path`,`type`,`upload`,`virtual_path`) values (1,'F:/upload/noteblogv4/img/2019-07-20/a2c523ca-6690-451f-87bb-9cc9b2665cd8.png','image/png','2019-07-20 16:06:04','/upfiles/img/2019-07-20/a2c523ca-6690-451f-87bb-9cc9b2665cd8.png'),(2,'F:/upload/noteblogv4/img/2019-07-22/e3ebebab-eb1a-4d4e-90ae-b9b302e61e05.jpg','image/jpeg','2019-07-22 09:34:19','/upfiles/img/2019-07-22/e3ebebab-eb1a-4d4e-90ae-b9b302e61e05.jpg'),(3,'F:/upload/noteblogv4/img/2019-07-22/d2216f64-8c2b-4966-bd22-1ddfa2ef9681.jpg','image/jpeg','2019-07-22 09:34:54','/upfiles/img/2019-07-22/d2216f64-8c2b-4966-bd22-1ddfa2ef9681.jpg'),(4,'D:/upload/noteblogv4/img/2020-05-31/efb6d29e-655a-48aa-95ac-972c5397fcd3.jpg','image/jpeg','2020-05-31 21:01:43','/upfiles/img/2020-05-31/efb6d29e-655a-48aa-95ac-972c5397fcd3.jpg'),(5,'D:/upload/noteblogv4/img/2020-05-31/49b00cc7-db4c-4d5c-b375-3194aefd98b3.jpg','image/jpeg','2020-05-31 21:08:03','/upfiles/img/2020-05-31/49b00cc7-db4c-4d5c-b375-3194aefd98b3.jpg'),(6,'D:/upload/noteblogv4/img/2020-05-31/0fafa4f0-d3b6-45d8-8d0a-adc64768ad6c.jpg','image/jpeg','2020-05-31 21:20:23','/upfiles/img/2020-05-31/0fafa4f0-d3b6-45d8-8d0a-adc64768ad6c.jpg'),(7,'D:/upload/noteblogv4/img/2020-05-31/7701a8f7-50a4-42eb-983e-ad023fb85e36.jpg','image/jpeg','2020-05-31 21:21:48','/upfiles/img/2020-05-31/7701a8f7-50a4-42eb-983e-ad023fb85e36.jpg'),(8,'D:/upload/noteblogv4/img/2020-05-31/433e9f7a-3352-4360-86a4-320c77f5a425.jpg','image/jpeg','2020-05-31 21:54:18','/upfiles/img/2020-05-31/433e9f7a-3352-4360-86a4-320c77f5a425.jpg');

/*Table structure for table `sys_logger` */

DROP TABLE IF EXISTS `sys_logger`;

CREATE TABLE `sys_logger` (
  `id` varchar(255) NOT NULL,
  `content_type` varchar(255) DEFAULT NULL,
  `ip_addr` varchar(255) DEFAULT NULL,
  `ip_info` varchar(255) DEFAULT NULL,
  `request_method` varchar(255) DEFAULT NULL,
  `session_id` varchar(255) DEFAULT NULL,
  `time` datetime DEFAULT NULL,
  `url` varchar(255) DEFAULT NULL,
  `user_agent` varchar(255) DEFAULT NULL,
  `username` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `sys_logger` */

insert  into `sys_logger`(`id`,`content_type`,`ip_addr`,`ip_info`,`request_method`,`session_id`,`time`,`url`,`user_agent`,`username`) values ('40288089726abb6001726af668ae0000','application/x-www-form-urlencoded; charset=UTF-8','0:0:0:0:0:0:0:1','开发中内网地址','POST','8538c72b-f5e4-4e8a-be3f-24316f69056d','2020-05-31 21:40:33','http://localhost:8089/management/settings/update','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/83.0.4103.61 Safari/537.36','');

/*Table structure for table `sys_menu` */

DROP TABLE IF EXISTS `sys_menu`;

CREATE TABLE `sys_menu` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `enable` tinyint(1) NOT NULL,
  `icon` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `order_index` int(11) DEFAULT NULL,
  `parent_id` bigint(20) NOT NULL,
  `remark` varchar(255) DEFAULT NULL,
  `role_id` bigint(20) DEFAULT NULL,
  `type` varchar(255) DEFAULT NULL,
  `resource_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FKr4hyo6ex6quothveikqr6tfkk` (`resource_id`),
  CONSTRAINT `FKr4hyo6ex6quothveikqr6tfkk` FOREIGN KEY (`resource_id`) REFERENCES `sys_resource` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=32 DEFAULT CHARSET=utf8;

/*Data for the table `sys_menu` */

insert  into `sys_menu`(`id`,`enable`,`icon`,`name`,`order_index`,`parent_id`,`remark`,`role_id`,`type`,`resource_id`) values (1,1,'layui-icon layui-icon-home','菜单根目录',0,0,NULL,NULL,'ROOT',NULL),(2,1,'layui-icon layui-icon-console','仪表盘',0,1,'管理页面仪表盘界面',1,'PARENT',4),(3,0,'layui-icon layui-icon-auz','权限管理',1,1,NULL,1,'PARENT',NULL),(4,0,'fa fa-list-ul','菜单管理',0,3,'菜单管理页面',1,'LEAF',8),(5,0,'fa fa-user-o','角色管理',1,3,'后台角色管理页面',1,'LEAF',16),(6,0,'fa fa-users','用户管理',2,3,'用户管理界面',1,'LEAF',22),(7,1,'layui-icon layui-icon-edit','内容发布',2,1,NULL,1,'PARENT',NULL),(8,1,'fa fa-send-o','发布文章',0,7,'博文发布页面',1,'LEAF',34),(9,1,'fa fa-file-text-o','随记随笔',1,7,'随笔/笔记发布页面',1,'LEAF',50),(10,1,'layui-icon layui-icon-template-1','内容管理',3,1,NULL,1,'PARENT',NULL),(11,1,'fa fa-newspaper-o','文章管理',0,10,'博文管理页面',1,'LEAF',42),(12,1,'fa fa-file-o','随笔管理',1,10,'随笔管理页面',1,'LEAF',49),(13,1,'layui-icon layui-icon-read','字典管理',4,1,NULL,1,'PARENT',NULL),(14,1,'fa fa-clone','分类管理',0,13,'分类管理页面',1,'LEAF',55),(15,1,'fa fa-hdd-o','项目分类管理',1,13,'项目分类管理页面',1,'LEAF',71),(16,1,'fa fa-hdd-o','云文件分类管理',2,13,'云文件分类管理页面',1,'LEAF',60),(17,1,'fa fa-dot-circle-o','关键字管理',3,13,'关键字管理页面',1,'LEAF',64),(18,1,'fa fa-tags','标签管理',4,13,'标签管理页面',1,'LEAF',77),(19,1,'layui-icon layui-icon-set','偏好设置',5,1,NULL,1,'PARENT',NULL),(20,1,'fa fa-qrcode','二维码设置',0,19,'微信和支付宝二维码图片设置界面',1,'LEAF',102),(21,1,'fa fa-cogs','网站基本设置',1,19,'网站基本设置界面',1,'LEAF',100),(22,1,'fa fa-cog','网站风格设置',2,19,'网站风格设置界面',1,'LEAF',103),(23,1,'fa fa-address-card-o','个人资料',3,19,'管理员个人信息设置',1,'LEAF',101),(24,1,'fa fa-server','邮件服务器',4,19,'网站发送邮件服务器设置',1,'LEAF',104),(25,1,'layui-icon layui-icon-diamond','个人内容',6,1,NULL,1,'PARENT',NULL),(26,1,'fa fa-hdd-o','关于内容',0,25,'关于tab内容管理页面',1,'LEAF',84),(27,1,'fa fa-laptop','资源项目分享',1,25,'项目管理页面',1,'LEAF',93),(28,1,'fa fa-file-archive-o','云文件分享',2,25,'云文件管理页面',1,'LEAF',27),(29,1,'layui-icon layui-icon-username','消息管理',7,1,NULL,1,'PARENT',NULL),(30,1,'fa fa-comments-o','评论管理',0,29,'评论管理页面',1,'LEAF',80),(31,1,'fa fa-globe','留言管理',1,29,'消息管理页面',1,'LEAF',83);

/*Table structure for table `sys_resource` */

DROP TABLE IF EXISTS `sys_resource`;

CREATE TABLE `sys_resource` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `group` varchar(255) DEFAULT NULL,
  `name` varchar(50) NOT NULL,
  `permission` varchar(50) NOT NULL,
  `type` varchar(255) DEFAULT NULL,
  `url` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=109 DEFAULT CHARSET=utf8;

/*Data for the table `sys_resource` */

insert  into `sys_resource`(`id`,`group`,`name`,`permission`,`type`,`url`) values (1,'PAGE','用户注销请求地址','user:logout:page','OTHER','/management/logout'),(2,'PAGE','字体图标预览','user:font:page','NAV_LINK','/font/list'),(3,'PAGE','后台管理首页','management:index:page','OTHER','/management/index'),(4,'ROUTER','管理页面仪表盘界面','management:index:dashboard','NAV_LINK','/management/dashboard'),(5,'AJAX','添加新角色操作','permission:role:create','OTHER','/management/role/create'),(6,'AJAX','删除角色菜单','permission:menu:delete','OTHER','/management/menu/delete'),(7,'AJAX','更新角色所拥有的资源信息','permission:role:update_role_resource','OTHER','/management/update/role/resource'),(8,'ROUTER','菜单管理页面','permission:menu:router','NAV_LINK','/management/menu'),(9,'AJAX','修改角色操作','permission:role:update','OTHER','/management/role/update'),(10,'AJAX','菜单管理界面的菜单数据','permission:menu:table_list','OTHER','/management/menu/list'),(11,'AJAX','修改角色菜单','permission:menu:update','OTHER','/management/menu/update'),(12,'AJAX','删除角色操作','permission:role:delete','OTHER','/management/role/delete'),(13,'ROUTER','添加角色菜单界面','permission:menu:add','OTHER','/management/menu/add'),(14,'ROUTER','修改角色菜单界面','permission:menu:edit','OTHER','/management/menu/edit'),(15,'AJAX','添加新角色菜单操作','permission:menu:create','OTHER','/management/menu/create'),(16,'ROUTER','后台角色管理页面','permission:role:router','NAV_LINK','/management/role'),(17,'AJAX','后台角色管理页面的资源树','permission:role:resource_tree','OTHER','/management/resource/tree'),(18,'AJAX','用户信息分页数据','management:user:table_list','OTHER','/management/users/list'),(19,'AJAX','修改用户的角色关联信息','management:user:role_update','OTHER','/management/users/roles/id/update'),(20,'AJAX','修改用户的角色关联信息','management:user:role_update','OTHER','/management/users/roles/str/update'),(21,'AJAX','查询用户的角色信息','management:user:role_list','OTHER','/management/users/roles/list'),(22,'ROUTER','用户管理界面','management:user:router','NAV_LINK','/management/users'),(23,'AJAX','修改用户状态信息','management:user:enable_update','OTHER','/management/users/enable/update'),(24,'AJAX','修改用户昵称信息','management:user:nickname_update','OTHER','/management/users/nickname/update'),(25,'ROUTER','云文件发布页面','management:cloudFile:add_page','NAV_LINK','/management/cloudFile/add'),(26,'AJAX','删除云文件操作','management:cloudFile:delete','OTHER','/management/cloudFile/delete/{id}'),(27,'ROUTER','云文件管理页面','management:cloudFile:list_page','NAV_LINK','/management/cloudFile'),(28,'ROUTER','云文件管编辑页面','management:cloudFile:edit_page','OTHER','/management/cloudFile/edit'),(29,'AJAX','修改一个云文件','management:cloudFile:update','OTHER','/management/cloudFile/update'),(30,'AJAX','发布一个新的项目','management:cloudFile:create','OTHER','/management/cloudFile/create'),(31,'AJAX','云文件管理页面中的数据接口','management:cloudFile:list_data','OTHER','/management/cloudFile/list'),(32,'AJAX','删除文章操作','management:article:delete','OTHER','/management/article/delete/{id}'),(33,'AJAX','修改文章的置顶状态','management:article:update_top','OTHER','/management/article/update/top/{id}'),(34,'ROUTER','博文发布页面','management:article:post_page','NAV_LINK','/management/article/post'),(35,'AJAX','修改文章的可评论状态','management:article:update_commented','OTHER','/management/article/update/commented/{id}'),(36,'AJAX','修改文章的可赞赏状态','management:article:update_appreciable','OTHER','/management/article/update/appreciable/{id}'),(37,'AJAX','编辑文章页面的tag数据包含选中的(selected)','management:article:edit_article_tags','OTHER','/management/article/edit/tags'),(38,'AJAX','修改一篇博文','management:article:update','OTHER','/management/article/update'),(39,'AJAX','发布一篇新的博文','management:article:create','OTHER','/management/article/create'),(40,'ROUTER','博文管编辑页面','management:article:edit_page','OTHER','/management/article/edit'),(41,'AJAX','博文管理页面中的数据接口','management:article:list_data','OTHER','/management/article/list'),(42,'ROUTER','博文管理页面','management:article:list_page','NAV_LINK','/management/article'),(43,'AJAX','删除笔记操作','management:note:delete','OTHER','/management/note/delete/{id}'),(44,'AJAX','修改笔记的置顶状态','management:note:update_top','OTHER','/management/note/update/top/{id}'),(45,'AJAX','修改一篇随笔/笔记','management:note:update','OTHER','/management/note/update'),(46,'AJAX','修改笔记的显隐状态','management:note:update_show','OTHER','/management/note/update/show/{id}'),(47,'AJAX','编辑随笔/笔记页面的tag数据包含选中的(selected)','management:note:edit_note_tags','OTHER','/management/note/edit/tags'),(48,'AJAX','随笔管理页面中的数据接口','management:note:list_data','OTHER','/management/note/list'),(49,'ROUTER','随笔管理页面','management:note:list_page','NAV_LINK','/management/note'),(50,'ROUTER','随笔/笔记发布页面','management:note:post_page','NAV_LINK','/management/note/post'),(51,'AJAX','发布一篇新的随笔/笔记','management:note:create','OTHER','/management/note/create'),(52,'ROUTER','随笔管编辑页面','management:note:edit_page','OTHER','/management/note/edit'),(53,'AJAX','修改分类操作','management:cate:update','OTHER','/management/dictionary/cate/update'),(54,'AJAX','删除分类操作','management:cate:delete','OTHER','/management/dictionary/cate/delete'),(55,'ROUTER','分类管理页面','management:cate:page','NAV_LINK','/management/dictionary/cate'),(56,'AJAX','分类管理分页数据','management:cate:list','OTHER','/management/dictionary/cate/list'),(57,'AJAX','添加分类操作','management:cate:create','OTHER','/management/dictionary/cate/create'),(58,'AJAX','修改云文件分类操作','management:cloudFileCate:update','OTHER','/management/dictionary/cloudFileCate/update'),(59,'AJAX','删除云文件分类操作','management:cloudFileCate:delete','OTHER','/management/dictionary/cloudFileCate/delete'),(60,'ROUTER','云文件分类管理页面','management:cloudFileCate:page','NAV_LINK','/management/dictionary/cloudFileCate'),(61,'AJAX','云文件分类管理分页数据','management:cloudFileCate:list','OTHER','/management/dictionary/cloudFileCate/list'),(62,'AJAX','添加云文件分类操作','management:cloudFileCate:create','OTHER','/management/dictionary/cloudFileCate/create'),(63,'AJAX','删除关键字操作','management:keyword:delete','OTHER','/management/dictionary/keyword/delete'),(64,'ROUTER','关键字管理页面','management:keyword:page','NAV_LINK','/management/dictionary/keyword'),(65,'AJAX','更新关键字状态操作','management:keyword:enable_update','OTHER','/management/dictionary/keyword/update/enable'),(66,'AJAX','关键字管理分页数据','management:keyword:list','OTHER','/management/dictionary/keyword/list'),(67,'AJAX','添加关键字操作','management:keyword:create','OTHER','/management/dictionary/keyword/create'),(68,'AJAX','更新关键字文本操作','management:keyword:update','OTHER','/management/dictionary/keyword/update'),(69,'AJAX','修改项目分类操作','management:projectCate:update','OTHER','/management/dictionary/projectCate/update'),(70,'AJAX','删除项目分类操作','management:projectCate:delete','OTHER','/management/dictionary/projectCate/delete'),(71,'ROUTER','项目分类管理页面','management:projectCate:page','NAV_LINK','/management/dictionary/projectCate'),(72,'AJAX','项目分类管理分页数据','management:projectCate:list','OTHER','/management/dictionary/projectCate/list'),(73,'AJAX','添加项目分类操作','management:projectCate:create','OTHER','/management/dictionary/projectCate/create'),(74,'AJAX','修改标签数据操作接口','management:tag:update','OTHER','/management/dictionary/tag/update'),(75,'AJAX','删除标签数据操作接口','management:tag:delete','OTHER','/management/dictionary/tag/delete'),(76,'AJAX','标签管理页面分页数据接口','management:tag:list','OTHER','/management/dictionary/tag/list'),(77,'ROUTER','标签管理页面','management:tag:page','NAV_LINK','/management/dictionary/tag'),(78,'AJAX','修改评论状态','management:comment:update','OTHER','/management/comment/update'),(79,'AJAX','评论管理页面分页数据接口','management:comment:list','OTHER','/management/comment/list'),(80,'ROUTER','评论管理页面','management:comment:page','NAV_LINK','/management/comment'),(81,'AJAX','修改评论状态','management:message:update','OTHER','/management/message/update'),(82,'AJAX','消息管理页面分页数据接口','management:message:list','OTHER','/management/message/list'),(83,'ROUTER','消息管理页面','management:message:page','NAV_LINK','/management/message'),(84,'ROUTER','关于tab内容管理页面','management:profile:page','NAV_LINK','/management/profile'),(85,'AJAX','删除关于tab内容操作','management:profile:delete','OTHER','/management/profile/delete'),(86,'ROUTER','添加tab页面','management:profile:add','NAV_LINK','/management/profile/add'),(87,'ROUTER','tab内容编辑页面','management:profile:edit','OTHER','/management/profile/edit'),(88,'AJAX','添加关于关于tab内容操作','management:profile:create','OTHER','/management/profile/create'),(89,'AJAX','更新关于tab内容操作','management:profile:update','OTHER','/management/profile/update'),(90,'AJAX','关于tab内容管理分页数据','management:profile:list','OTHER','/management/profile/list'),(91,'ROUTER','项目发布页面','management:project:add_page','NAV_LINK','/management/project/add'),(92,'AJAX','删除项目操作','management:project:delete','OTHER','/management/project/delete/{id}'),(93,'ROUTER','项目管理页面','management:project:list_page','NAV_LINK','/management/project'),(94,'ROUTER','项目管编辑页面','management:project:edit_page','OTHER','/management/project/edit'),(95,'AJAX','修改一篇项目','management:project:update','OTHER','/management/project/update'),(96,'AJAX','发布一个新的项目','management:project:create','OTHER','/management/project/create'),(97,'AJAX','项目管理页面中的数据接口','management:project:list_data','OTHER','/management/project/list'),(98,'AJAX','网站设置修改操作','management:settings:update','OTHER','/management/settings/update'),(99,'AJAX','网站邮件服务器修改操作','management:settings:mail_update','OTHER','/management/settings/mail/update'),(100,'ROUTER','网站基本设置界面','management:settings:common','NAV_LINK','/management/settings/common'),(101,'ROUTER','管理员个人信息设置','management:settings:profile','NAV_LINK','/management/settings/profile'),(102,'ROUTER','微信和支付宝二维码图片设置界面','management:settings:qrcode','NAV_LINK','/management/settings/qrcode'),(103,'ROUTER','网站风格设置界面','management:settings:theme','NAV_LINK','/management/settings/theme'),(104,'ROUTER','网站发送邮件服务器设置','management:settings:mail','NAV_LINK','/management/settings/mail'),(105,'AJAX','支付宝/微信二维码修改操作','management:settings:pay_update','OTHER','/management/settings/pay/update'),(106,'AJAX','网站管理员修改操作','management:settings:profile_update','OTHER','/management/settings/profile/update'),(107,'AJAX','通用上传接口','management:common:upload','OTHER','/management/upload'),(108,'AJAX','editormd编辑器上传接口','management:editormd:upload','OTHER','/management/upload/editorMD');

/*Table structure for table `sys_role` */

DROP TABLE IF EXISTS `sys_role`;

CREATE TABLE `sys_role` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `cn_name` varchar(50) DEFAULT NULL,
  `name` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT;

/*Data for the table `sys_role` */

insert  into `sys_role`(`id`,`cn_name`,`name`) values (1,'网站管理员','ROLE_MASTER'),(2,'网站访客','ROLE_USER');

/*Table structure for table `sys_role_resource` */

DROP TABLE IF EXISTS `sys_role_resource`;

CREATE TABLE `sys_role_resource` (
  `resource_id` bigint(20) NOT NULL,
  `role_id` bigint(20) NOT NULL,
  `enable` tinyint(1) NOT NULL,
  PRIMARY KEY (`resource_id`,`role_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `sys_role_resource` */

insert  into `sys_role_resource`(`resource_id`,`role_id`,`enable`) values (1,1,1),(2,1,1),(3,1,1),(4,1,1),(5,1,1),(6,1,1),(7,1,1),(8,1,1),(9,1,1),(10,1,1),(11,1,1),(12,1,1),(13,1,1),(14,1,1),(15,1,1),(16,1,1),(17,1,1),(18,1,1),(19,1,1),(20,1,1),(21,1,1),(22,1,1),(23,1,1),(24,1,1),(25,1,1),(26,1,1),(27,1,1),(28,1,1),(29,1,1),(30,1,1),(31,1,1),(32,1,1),(33,1,1),(34,1,1),(35,1,1),(36,1,1),(37,1,1),(38,1,1),(39,1,1),(40,1,1),(41,1,1),(42,1,1),(43,1,1),(44,1,1),(45,1,1),(46,1,1),(47,1,1),(48,1,1),(49,1,1),(50,1,1),(51,1,1),(52,1,1),(53,1,1),(54,1,1),(55,1,1),(56,1,1),(57,1,1),(58,1,1),(59,1,1),(60,1,1),(61,1,1),(62,1,1),(63,1,1),(64,1,1),(65,1,1),(66,1,1),(67,1,1),(68,1,1),(69,1,1),(70,1,1),(71,1,1),(72,1,1),(73,1,1),(74,1,1),(75,1,1),(76,1,1),(77,1,1),(78,1,1),(79,1,1),(80,1,1),(81,1,1),(82,1,1),(83,1,1),(84,1,1),(85,1,1),(86,1,1),(87,1,1),(88,1,1),(89,1,1),(90,1,1),(91,1,1),(92,1,1),(93,1,1),(94,1,1),(95,1,1),(96,1,1),(97,1,1),(98,1,1),(99,1,1),(100,1,1),(101,1,1),(102,1,1),(103,1,1),(104,1,1),(105,1,1),(106,1,1),(107,1,1),(108,1,1);

/*Table structure for table `sys_user` */

DROP TABLE IF EXISTS `sys_user`;

CREATE TABLE `sys_user` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `avatar` varchar(100) DEFAULT NULL,
  `create` datetime DEFAULT NULL,
  `default_role_id` bigint(20) NOT NULL,
  `email` varchar(255) DEFAULT NULL,
  `enable` tinyint(1) NOT NULL,
  `nickname` varchar(50) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `qq_num` varchar(20) DEFAULT NULL,
  `qq_open_id` varchar(255) DEFAULT NULL,
  `username` varchar(20) DEFAULT NULL,
  `wechat_open_id` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

/*Data for the table `sys_user` */

insert  into `sys_user`(`id`,`avatar`,`create`,`default_role_id`,`email`,`enable`,`nickname`,`password`,`qq_num`,`qq_open_id`,`username`,`wechat_open_id`) values (1,'/upfiles/img/2020-05-31/efb6d29e-655a-48aa-95ac-972c5397fcd3.jpg','2019-07-19 11:12:48',1,'123456789@qq.com',1,'blog_user','14e1b600b1fd579f47433b88e8d85291',NULL,NULL,'admin',NULL),(2,'/static/assets/img/favicon.png','2020-05-31 20:38:31',2,NULL,1,'wkz','14e1b600b1fd579f47433b88e8d85291',NULL,NULL,'王凯正123',NULL);

/*Table structure for table `sys_user_role` */

DROP TABLE IF EXISTS `sys_user_role`;

CREATE TABLE `sys_user_role` (
  `role_id` bigint(20) NOT NULL,
  `user_id` bigint(20) NOT NULL,
  `enable` tinyint(1) NOT NULL,
  PRIMARY KEY (`role_id`,`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `sys_user_role` */

insert  into `sys_user_role`(`role_id`,`user_id`,`enable`) values (1,1,1),(2,2,1);

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
