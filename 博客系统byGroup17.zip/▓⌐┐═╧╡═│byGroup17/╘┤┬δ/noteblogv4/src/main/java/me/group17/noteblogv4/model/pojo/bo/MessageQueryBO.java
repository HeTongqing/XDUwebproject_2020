package me.group17.noteblogv4.model.pojo.bo;

import lombok.Data;
import lombok.ToString;

import java.io.Serializable;

/**
 * created by group17 on 2020/5/7 at 11:05
 *
 * @author group17
 */
@ToString
@Data
public class MessageQueryBO implements Serializable {
    private String clearComment;
    private String ipCnAddr;
    private Long userId;
}
