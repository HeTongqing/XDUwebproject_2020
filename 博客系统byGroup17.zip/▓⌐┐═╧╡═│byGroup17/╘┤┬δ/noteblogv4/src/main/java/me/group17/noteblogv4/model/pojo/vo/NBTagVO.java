package me.group17.noteblogv4.model.pojo.vo;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;
import me.group17.noteblogv4.model.entity.NBTag;
import me.group17.noteblogv4.model.entity.NBTag;

/**
 * created by group17 on 2020/5/10 at 10:31
 * @author group17
 */
@Setter
@Getter
@ToString
public class NBTagVO extends NBTag {
    private String selected;
}
