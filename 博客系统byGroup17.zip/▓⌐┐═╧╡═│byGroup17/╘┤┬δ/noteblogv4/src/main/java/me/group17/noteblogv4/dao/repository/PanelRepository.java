package me.group17.noteblogv4.dao.repository;

import me.group17.noteblogv4.model.entity.NBPanel;
import org.springframework.data.jpa.repository.JpaRepository;

/**
 * created by group17 on 2020/5/19 at 下午3:04
 * @author group17
 */
public interface PanelRepository extends JpaRepository<NBPanel, Long> {
}
