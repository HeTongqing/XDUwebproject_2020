package me.group17.noteblogv4.service.content;

import me.group17.noteblogv4.model.entity.NBMessage;
import me.group17.noteblogv4.model.entity.NBMessage;
import me.group17.noteblogv4.model.pojo.bo.MessageQueryBO;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;


public interface MessageService {

    /**
     * 查询消息的分页信息
     *
     * @param pageable
     * @param messageQueryBO
     * @return
     */
    Page<NBMessage> findPageInfo(Pageable pageable, MessageQueryBO messageQueryBO);
}
