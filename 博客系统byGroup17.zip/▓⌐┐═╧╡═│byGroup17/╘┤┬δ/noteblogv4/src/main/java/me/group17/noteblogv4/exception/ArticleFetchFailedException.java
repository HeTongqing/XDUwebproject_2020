package me.group17.noteblogv4.exception;

/**
 * created by group17 on 2020/5/10 at 11:10
 *
 * @author group17
 */
public class ArticleFetchFailedException extends RuntimeException {
    public ArticleFetchFailedException() {
        super("文章获取失败！");
    }

    public ArticleFetchFailedException(String message) {
        super(message);
    }
}
