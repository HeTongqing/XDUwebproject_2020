package me.group17.noteblogv4.dao.repository;

import me.group17.noteblogv4.model.entity.NBUpload;
import me.group17.noteblogv4.model.entity.NBUpload;
import org.springframework.data.jpa.repository.JpaRepository;

/**
 * created by group17 on 2020/5/4 at 0:03
 * @author group17
 */
public interface UploadRepository extends JpaRepository<NBUpload, Long> {
}
