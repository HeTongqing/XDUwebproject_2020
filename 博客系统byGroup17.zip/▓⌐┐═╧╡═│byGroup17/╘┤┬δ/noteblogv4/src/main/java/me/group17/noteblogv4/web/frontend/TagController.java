package me.group17.noteblogv4.web.frontend;

import me.group17.noteblogv4.dao.repository.TagRepository;
import me.group17.noteblogv4.model.entity.NBTag;
import me.group17.noteblogv4.dao.repository.TagRepository;
import me.group17.noteblogv4.model.entity.NBTag;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import java.util.List;

/**
 * created by group17 on 2020/5/4 at 11:25
 *
 * @author group17
 */
@Controller
@RequestMapping("/tag")
public class TagController {

    private final TagRepository tagRepository;

    @Autowired
    public TagController(TagRepository tagRepository) {
        this.tagRepository = tagRepository;
    }

    @GetMapping("/all")
    @ResponseBody
    public List<NBTag> tagsList() {
        return tagRepository.findAll();
    }
}
