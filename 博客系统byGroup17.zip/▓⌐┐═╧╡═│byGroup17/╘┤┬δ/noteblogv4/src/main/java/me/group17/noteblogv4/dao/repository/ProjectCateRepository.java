package me.group17.noteblogv4.dao.repository;

import me.group17.noteblogv4.model.entity.NBProjectCate;
import me.group17.noteblogv4.model.entity.NBProjectCate;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

/**
 * created by group17 on 2020/5/3 at 11:16
 *
 * @author group17
 */
public interface ProjectCateRepository extends JpaRepository<NBProjectCate, Long> {

    /**
     * 查找已存在对应的分类数目
     *
     * @param cate
     * @return
     */
    @Query("SELECT COUNT(c) FROM NBProjectCate c WHERE c.cnName = :#{#cate.cnName} AND c.name = :#{#cate.name}")
    long findCateCount(@Param("cate") NBProjectCate cate);
}
