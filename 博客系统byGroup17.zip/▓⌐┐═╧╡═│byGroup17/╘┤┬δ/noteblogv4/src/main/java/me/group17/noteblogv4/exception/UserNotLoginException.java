package me.group17.noteblogv4.exception;

/**
 * 用户未登录或超时
 * created by group17 on 2020/5/20 at 14:22
 *
 * @author group17
 */
public class UserNotLoginException extends RuntimeException {
    public UserNotLoginException() {
        super();
    }

    public UserNotLoginException(String message) {
        super(message);
    }
}
