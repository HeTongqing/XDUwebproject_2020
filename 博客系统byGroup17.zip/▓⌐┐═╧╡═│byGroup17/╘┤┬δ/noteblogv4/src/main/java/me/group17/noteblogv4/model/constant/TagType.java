package me.group17.noteblogv4.model.constant;

/**
 * 区分文章还是笔记
 * created by group17 on 2020/5/17 at 10:51
 * @author group17
 */
public enum TagType {

    /**
     * 文章
     */
    article,

    /**
     * 笔记
     */
    note
}
