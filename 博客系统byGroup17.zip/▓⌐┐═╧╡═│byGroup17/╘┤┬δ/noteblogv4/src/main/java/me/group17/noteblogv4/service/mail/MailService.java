package me.group17.noteblogv4.service.mail;

import me.group17.noteblogv4.model.entity.NBArticle;
import me.group17.noteblogv4.model.entity.NBArticle;

/**
 * created by group17 on 2019-01-08 at 22:27
 * @author group17
 */
public interface MailService {

    /**
     * 发送评论通知邮件
     * @param site
     * @param article
     * @param comment
     */
    void sendNoticeMail(String site, NBArticle article, String comment);
}
