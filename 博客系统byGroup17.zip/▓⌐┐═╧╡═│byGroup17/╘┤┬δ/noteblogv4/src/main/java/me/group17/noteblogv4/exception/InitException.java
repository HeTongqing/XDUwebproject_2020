package me.group17.noteblogv4.exception;

/**
 * created by group17 on 2020/5/28 at 21:17
 * @author group17
 */
public class InitException extends RuntimeException {
    public InitException() {
        super();
    }

    public InitException(String message) {
        super(message);
    }

    public InitException(String message, Throwable cause) {
        super(message, cause);
    }

    public InitException(Throwable cause) {
        super(cause);
    }
}
