package me.group17.noteblogv4.dao.repository;

import me.group17.noteblogv4.model.entity.NBCloudFile;
import me.group17.noteblogv4.model.entity.NBCloudFile;
import org.springframework.data.jpa.repository.JpaRepository;

/**
 * created by group17 on 2020/5/13 at 16:33
 *
 * @author group17
 */
public interface CloudFileRepository extends JpaRepository<NBCloudFile, Long> {

    /**
     * 计算某个cateId说下的数量
     *
     * @param cateId
     * @return
     */
    long countByCateId(long cateId);

}
