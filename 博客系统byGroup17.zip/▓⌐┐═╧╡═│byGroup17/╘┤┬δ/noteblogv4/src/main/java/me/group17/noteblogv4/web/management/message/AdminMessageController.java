package me.group17.noteblogv4.web.management.message;

import me.group17.noteblogv4.config.permission.NBAuth;
import me.group17.noteblogv4.dao.repository.MessageRepository;
import me.group17.noteblogv4.model.entity.NBMessage;
import me.group17.noteblogv4.model.entity.permission.NBSysResource;
import me.group17.noteblogv4.model.pojo.framework.LayuiTable;
import me.group17.noteblogv4.model.pojo.framework.NBR;
import me.group17.noteblogv4.model.pojo.framework.Pagination;
import me.group17.noteblogv4.web.BaseController;
import me.group17.noteblogv4.config.permission.NBAuth;
import me.group17.noteblogv4.dao.repository.MessageRepository;
import me.group17.noteblogv4.model.entity.NBMessage;
import me.group17.noteblogv4.model.pojo.framework.LayuiTable;
import me.group17.noteblogv4.model.pojo.framework.NBR;
import me.group17.noteblogv4.model.pojo.framework.Pagination;
import me.group17.noteblogv4.web.BaseController;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.*;
import org.springframework.stereotype.Controller;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import static me.group17.noteblogv4.config.permission.NBAuth.Group.AJAX;
import static me.group17.noteblogv4.config.permission.NBAuth.Group.ROUTER;

/**
 * created by group17 on 2020/5/15 at 16:28
 *
 * @author group17
 */
@Controller
@RequestMapping("/management/message")
public class AdminMessageController extends BaseController {

    private final MessageRepository messageRepository;

    @Autowired
    public AdminMessageController(MessageRepository messageRepository) {
        this.messageRepository = messageRepository;
    }

    @RequestMapping
    @NBAuth(value = "management:message:page", remark = "消息管理页面", group = NBAuth.Group.ROUTER, type = NBSysResource.ResType.NAV_LINK)
    public String tagIndex() {
        return "management/message/message";
    }

    @RequestMapping("/list")
    @ResponseBody
    @NBAuth(value = "management:message:list", remark = "消息管理页面分页数据接口", group = NBAuth.Group.AJAX)
    public LayuiTable<NBMessage> cateList(Pagination<NBMessage> messagePagination, String clearComment) {
        Sort sort = getJpaSort(messagePagination);
        Pageable pageable = PageRequest.of(messagePagination.getPage() - 1, messagePagination.getLimit(), sort);
        if (StringUtils.isEmpty(messagePagination)) {
            Page<NBMessage> tagPage = messageRepository.findAll(pageable);
            return layuiTable(tagPage, pageable);
        } else {
            Example<NBMessage> messageExample = Example.of(
                    NBMessage.builder().clearComment(clearComment).build(),
                    ExampleMatcher.matching()
                            .withMatcher("clearComment", ExampleMatcher.GenericPropertyMatcher::contains).withIgnoreCase()
                            .withIgnorePaths("post", "enable")
            );
            Page<NBMessage> commentPage = messageRepository.findAll(messageExample, pageable);
            return layuiTable(commentPage, pageable);
        }
    }


    @RequestMapping("/update")
    @ResponseBody
    @NBAuth(value = "management:message:update", remark = "修改评论状态", group = NBAuth.Group.AJAX)
    public NBR delete(@RequestParam("id") Long id, boolean enable) {
        return ajaxDone(
                () -> messageRepository.updateMessageStatus(id, enable) == 1,
                () -> "修改留言"
        );
    }
}
