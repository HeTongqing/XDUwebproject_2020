package me.group17.noteblogv4.model.pojo.vo;

import lombok.Builder;
import lombok.Data;

import java.io.Serializable;

/**
 * created by group17 on 2020/5/7 at 13:59
 *
 * @author group17
 */
@Data
@Builder
public class BaseDataStatistics implements Serializable {

    private String text;
    private long sum;
    @Builder.Default
    private String url = "";
}
