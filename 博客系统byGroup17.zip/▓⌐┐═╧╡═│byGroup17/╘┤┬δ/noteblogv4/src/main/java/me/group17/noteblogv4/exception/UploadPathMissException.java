package me.group17.noteblogv4.exception;

/**
 * created by group17 on 2020/5/3 at 23:10
 * @author group17
 */
public class UploadPathMissException extends RuntimeException {
    public UploadPathMissException() {
        super();
    }

    public UploadPathMissException(String message) {
        super(message);
    }

    public UploadPathMissException(String message, Throwable cause) {
        super(message, cause);
    }

    public UploadPathMissException(Throwable cause) {
        super(cause);
    }
}
