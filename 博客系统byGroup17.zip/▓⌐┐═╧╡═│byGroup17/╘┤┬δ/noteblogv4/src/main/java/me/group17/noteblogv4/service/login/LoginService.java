package me.group17.noteblogv4.service.login;

import me.group17.noteblogv4.model.pojo.framework.NBR;
import me.group17.noteblogv4.model.pojo.framework.NBR;


public interface LoginService<T> {


    /**
     * 登录方法
     *
     * @param data
     * @return
     */
    NBR doLogin(T data);


}
