package me.group17.noteblogv4.exception;

/**
 * 角色未授权
 * created by group17 on 2020/5/20 at 14:22
 *
 * @author group17
 */
public class UnauthorizedRoleException extends RuntimeException {
    public UnauthorizedRoleException() {
        super();
    }

    public UnauthorizedRoleException(String message) {
        super(message);
    }
}
