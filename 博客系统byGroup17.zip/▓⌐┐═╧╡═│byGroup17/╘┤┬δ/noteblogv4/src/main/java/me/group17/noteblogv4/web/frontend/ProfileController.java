package me.group17.noteblogv4.web.frontend;

import me.group17.noteblogv4.dao.repository.ProfileRepository;
import me.group17.noteblogv4.web.BaseController;
import me.group17.noteblogv4.dao.repository.ProfileRepository;
import me.group17.noteblogv4.web.BaseController;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

/**
 * created by group17 on 2020/5/25 at 13:09
 *
 * @author group17
 */
@Controller("frontProfileController")
@RequestMapping("/profile")
public class ProfileController extends BaseController {

    private final ProfileRepository profileRepository;

    @Autowired
    public ProfileController(ProfileRepository profileRepository) {
        this.profileRepository = profileRepository;
    }

    @RequestMapping
    public String profile(Model model) {
        model.addAttribute("abouts", profileRepository.findAll());
        return "frontend/profile";
    }
}
