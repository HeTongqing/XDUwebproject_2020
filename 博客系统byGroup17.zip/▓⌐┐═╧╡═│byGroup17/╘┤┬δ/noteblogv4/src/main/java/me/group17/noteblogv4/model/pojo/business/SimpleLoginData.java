package me.group17.noteblogv4.model.pojo.business;

import lombok.Data;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.Serializable;

/**
 * created by group17 on 2020/5/21 at 18:37
 * @author group17
 */
@Data
public class SimpleLoginData implements Serializable {

    private HttpServletRequest request;
    private HttpServletResponse response;
    private String bmyName;
    private String bmyPass;
    private Boolean remember;
    private String vercode;

}
