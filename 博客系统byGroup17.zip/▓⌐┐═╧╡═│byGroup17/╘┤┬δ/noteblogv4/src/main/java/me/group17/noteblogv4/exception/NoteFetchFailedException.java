package me.group17.noteblogv4.exception;

/**
 * created by group17 on 2020/5/10 at 11:10
 *
 * @author group17
 */
public class NoteFetchFailedException extends RuntimeException {
    public NoteFetchFailedException() {
        super("笔记获取失败！");
    }
}
