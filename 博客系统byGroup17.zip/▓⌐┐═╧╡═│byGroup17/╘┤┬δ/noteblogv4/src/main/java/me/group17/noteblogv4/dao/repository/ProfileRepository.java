package me.group17.noteblogv4.dao.repository;

import me.group17.noteblogv4.model.entity.NBAbout;
import org.springframework.data.jpa.repository.JpaRepository;

/**
 * created by group17 on 2020/5/8 at 23:05
 *
 * @author group17
 */
public interface ProfileRepository extends JpaRepository<NBAbout, Long> {
}
