package me.group17.noteblogv4.exception;

/**
 * created by group17 on 2020/5/3 at 22:16
 * @author group17
 */
public class MethodNotMatchException extends RuntimeException {
    public MethodNotMatchException() {
        super();
    }

    public MethodNotMatchException(String message) {
        super(message);
    }

    public MethodNotMatchException(String message, Throwable cause) {
        super(message, cause);
    }

    public MethodNotMatchException(Throwable cause) {
        super(cause);
    }
}
